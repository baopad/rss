<?php
echo '二级主页面默认main 测试页面<a href="./legal"> 二级legal页面</a> <a href="./lamp"> 二级LAMP页面</a>';