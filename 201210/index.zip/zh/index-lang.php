<?php
$lang='zh';
$local='legal';
?>