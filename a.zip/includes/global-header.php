<nav id="globalhead">
    <input type="checkbox" id="gh-menustates">
    <input type="checkbox" id="gh-secondarystates">
    <div id="gh-content"> 
        <!--Narrow navigation Bar-->
        <div class="gh-content-case">
            <div class="gh-meun">
                <div class="gh-header-menuicon">
                    <label class="gh-header-menuicon-label" for="gh-menustates">
                    <div class="gh-header-menuicon-label-case">
                        <div class="gh-header-menuicon-label-top">
                            <div class="gh-header-menuicon-label-top-crust"> </div>
                        </div>
                        <div class="gh-header-menuicon-label-midd">
                            <div class="gh-header-menuicon-label-midd-crust"> </div>
                        </div>
                        <div class="gh-header-menuicon-label-bottom">
                            <div class="gh-header-menuicon-label-bottom-crust"></div>
                        </div>
                    </div>
                    </label>
                </div>
            </div>
            <div class="gh-list-c8888ase">
                <div class="gh-header-logo"><a href="/">PAOTUNG'<span style="font-size: .75em;">BLOG</span></a></div>
            </div>
            <div class="gh-list">
                <ul class="gh-list-case">
                    <li class="gh-list-item"><a href="/">首页</a></li>
                    <?php
                    foreach ( $menu_arr as $key => $value ) {
                        if ( $value[ 'menu-display' ] == 1 ) {
                            $listget = $value[ 'menu-path' ];
                            $listtitle = $value[ 'menu-name' ];
                            $articlepath = $value[ 'menu-path' ];
                            echo '<li class="gh-list-item"><a href="' . $listget . '">' . "$listtitle" . '</a> </li>';
                        }
                    }
                    ?>
                    <li class="gh-list-item"><a href="/about/">关于</a></li>
                </ul>
            </div>
            <div class="gh-secondary">
                <ul class="gh-secondary-case">
                    <input type="checkbox" id="gh-secondaryproduct">
                    <li class="gh-secondary-product"> <span>搜</span> </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
