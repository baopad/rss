
<main id="localmain">
    <input type="checkbox" id="lm-menustates">
    <div id="lm-content">
        <div class="lm-content-case">
            <div class="lm-list">
                <div class="lm-list-case">
                    <div class="lm-list-name-case">
                        <div class="lm-list-case-title"> <a href="<?php echo $local_path ;?>"><?php echo $local_name ;?></a> </div>
                        <div class="lm-nav-menuicon">
                            <label class="lm-nav-menuicon-label" for="lm-menustates">
                            <div class="lm-nav-menuicon-label-case">
                                <div class="lm-nav-menuicon-label-left">
                                    <div class="lm-nav-menuicon-label-left-crust"></div>
                                </div>
                                <div class="lm-nav-menuicon-label-right">
                                    <div class="lm-nav-menuicon-label-right-crust"></div>
                                </div>
                            </div>
                            </label>
                        </div>
                    </div>
                    <div class="lm-list-case-case lm-def-narrow-blank">
                        <ul class="lm-list-case-subs">
                            <!-- <li class="lm-list-case-item"><a href="./?example">example</a> </li> -->
                            <?php
                            if ( isset( $list_arr ) ) {
                                //print_r($list_arr );
                                //echo $local_class;
                                foreach ( $list_arr as $key => $value ) {

                                    if ( $list_arr[ $key ][ "article-class" ] == $local_class ) {
                                        $article_get = $value[ 'article-get' ];
                                        $article_name = $value[ 'article-name' ];
                                        $article_path = $value[ 'article-path' ];
                                        echo '<li class="lm-list-case-item"><a href="./?' . $article_get . '">' . "$article_name" . '</a> </li>';
                                        if ( isset( $_GET[ "$article_get" ] ) == $article_get ) {
                                            $article_content = $root_dir . '/admin/' . "$article_path";
                                        }
                                    }
                                }
                            } else {
                                echo 'ERR,code=RDWGKG';
                            }
                            ?>
                        </ul>
                    </div>
                </div>
                <div class="lm-def-narrow-blank">
                    <?php
                    if ( file_exists( 'add-list.php' ) ) {
                        include( 'add-list.php' );
                    }
                    ?>
                </div>
            </div>
            <div class="lm-article">
                <div class="lm-article-case"> 
                    <!--*************************起始正文*******默认index-article******************-->
                    <?php
                    //echo 'article_content:' . $article_content . '<br>';
                    //echo 'article-get:' . $article_get . '<br>';
                    if ( !isset( $article_content ) ) {
                        $article_content = $root_dir . '/admin/index-' . "$local_class" . '.php';
                    }
                    file_exists( $article_content ) ? include $article_content : print "ERR,code=QHGVGG(Article does not exist!)";
                    ?>
                    <!--*************************结束*************************--> 
                </div>
            </div>
        </div>
    </div>
</main>
