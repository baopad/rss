<footer id="globalfoot">
    <div class="gf-content">
        <div class="gf-about">
            <div class="gf-about-case">
                <div class="gf-about-links">
					<a class="gf-about-links-item" href="/about?privacy">隐私政策</a>
					<span class="gf-about-links-space">|</span>
					<a class="gf-about-links-item" href="/about?terms">使用条款</a>
					<span class="gf-about-links-space">|</span>
					<a class="gf-about-links-item" href="/about/cookie/">Cookie选项</a>
					<span class="gf-about-links-space">|</span>
					<a class="gf-about-links-item" href="/sitemap/">网站地图</a>
				</div>
                <div class="gf-about-copyright">
					<span style="letter-spacing: 0.015em">©<?php echo date('Y'); ?>&nbsp;PAOTUNG.</span>
				</div>
            </div>
        </div>
    </div>
</footer>
