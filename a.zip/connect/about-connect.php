<!doctype html>
<html lang="<?php echo "$lang";?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="PAOTUNG">
<meta name="description" content="paotung website">
<link rel="stylesheet" type="text/css" href="./blogcontent.css">
<link rel="shortcut icon" href="/favicon/globalfavicon/favicon-pt.ico" type="image/x-icon">
<link rel="icon" href="/favicon/globalfavicon/favicon-pt_96.png" sizes="96">
<title>PAOTUNG</title>
</head>
<body style="direction:ltr;">
<?php
if ( !isset( $filehead ) ) {
    $filehead = $root_dir . $sys_dir . "/index-head.php";
}
if ( !isset( $filelocal ) ) {
    $filelocal = "./index-local.php";
}
if ( !isset( $filelist ) ) {
    $filelist = "./index-list.php";
}
if ( !isset( $filearticle ) ) {
    $filearticle = "./index-article.php";
}
if ( !isset( $filefoot ) ) {
    $filefoot = "./blogfooter.php";
}
$indexdatabase = 0;
	
file_exists( $filehead ) ? include $filehead : print "ERR404,code=LVRNFJ";
?>
<main id="localcontent">
    <input type="checkbox" id="lc-menustates">
    <div id="lc-content">
        <div class="lc-content-case">
            <?php
            file_exists( $filelocal ) ? include $filelocal : print "ERR404,code=WXJXNR";
            file_exists( $filelist ) ? include $filelist : print "ERR404,code=WBVJFS";
            ?>
        </div>
    </div>
</main>
<?php
file_exists( $filefoot ) ? include $filefoot : print "ERR404,code=PTFJBD";
?>
</body>
</html>
