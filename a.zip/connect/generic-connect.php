<?php
//载入菜单及列表变量
$global_variable = __DIR__ . '/global-variable.php';
file_exists( $global_variable ) ? include $global_variable : print "ERR,code=RGCJFS";
?>
<!doctype html>
<html lang="<?php echo "$lang";?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="PAOTUNG">
<meta name="description" content="paotung website">
<link rel="stylesheet" type="text/css" href="/includes/generic-style.css">
<link rel="shortcut icon" href="/favicon/globalfavicon/favicon-pt.ico" type="image/x-icon">
<link rel="icon" href="/favicon/globalfavicon/favicon-pt_96.png" sizes="96">
<title>PAOTUNG</title>
</head>
<body style="direction:ltr;">
<?php
if ( !isset( $global_head ) ) {
    $global_head = $root_dir . "/includes/global-header.php";
}
if ( !isset( $local_conten ) ) {
    $local_content = $root_dir . "/includes/local-content.php";
}
if ( ( $local_path == "\\" ) || ( $local_path == "\/" ) || ( $local_path == "/" ) ) {
    $local_content = $root_dir . '/admin/index.php';
}
if ( !isset( $global_foot ) ) {
    $global_foot = $root_dir . "/includes/global-footer.php";
}
//载入全局页眉、地内容、全局页尾
file_exists( $global_head ) ? include $global_head : print 'ERR,code=LVRNFJ';
file_exists( $local_content ) ? include $local_content : print "ERR,code=WBVJFS";
file_exists( $global_foot ) ? include $global_foot : print "ERR,code=PTFJBD";
?>
</body>
</html>
