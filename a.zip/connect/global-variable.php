<?php //所有菜单目录载入$menu_arr
$root_dir = $_SERVER[ 'DOCUMENT_ROOT' ];
$file = @fopen( $root_dir . '/admin/menu-subs.csv', 'r' );
if ( $file !== false ) {
    if ( ( $titlearticle[] = @fgetcsv( $file ) ) == FALSE ) {
        echo 'ERR,code=RDRFDC';
    }
    while ( ( $data = fgetcsv( $file ) ) !== FALSE ) {
        $goods_list[] = $data;
    }
    fclose( $file );

    foreach ( $titlearticle[ 0 ] as $key => $value ) {
        foreach ( $goods_list as $m => $n ) {
            $menu_arr[ $m ][ "$value" ] = $goods_list[ $m ][ $key ];
        }
    }
} else {
    echo 'ERR,code=RDCFKG';
} //搜索路径下对应名称和类别$list_arr
foreach ( $menu_arr as $key => $value ) {
    foreach ( $value as $m => $n ) {
        if ( $value[ "menu-path" ] == $local_path ) {
            $local_name = $value[ "menu-name" ]; //echo( $local_name );
            $local_class = $value[ "menu-class" ]; //echo( $local_class );
        }
    }
}
$file = @fopen( $root_dir . '/admin/article-subs.csv', 'r' );
if ( $file !== false ) {
    if ( ( $tcle[] = @fgetcsv( $file ) ) == FALSE ) {
        echo 'ERR,code=FTGFDC';
    }
    while ( ( $data = fgetcsv( $file ) ) !== FALSE ) {
        $article_list[] = $data;
    }
    fclose( $file );
    foreach ( $tcle[ 0 ] as $key => $value ) {
        foreach ( $article_list as $m => $n ) {
            $list_arr[ $m ][ "$value" ] = $article_list[ $m ][ $key ];
        }
    }
} else {
    echo 'ERR,code=GYCFKG';
}
//print_r($list_arr );