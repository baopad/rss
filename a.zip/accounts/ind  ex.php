<?php
if ( isset( $_GET[ 'logout' ] ) ) {
    setcookie( "user_name", " ", time() - 3600, "/" );
    setcookie( "user_status", 0, time(), "/" );
    header( "Location: ?login" );
}
// $Id:$ //声明变量 header( "Location:login.php?err=1" );
$log_message = '正常1注册窗口流';
$from_box = 1;

if ( !empty( $_COOKIE[ "user_status" ] ) ) {

    if ( !empty( $_COOKIE[ "user_name" ] ) ) {
        $from_box = 2;

        $log_message = "你已登录，返回首页";
    } else {
        $from_box = 1;
        setcookie( "user_name", " ", time() - 3600, "/" );
        $log_message = "未知用户名的密码，返回首页";
    }
} elseif ( !( isset( $_POST[ 'username' ] ) || isset( $_POST[ 'password' ] ) ) ) {
    $log_message = "正常2登录窗口";
} else {
    $username = $_POST[ 'username' ];
    $password = $_POST[ 'password' ];
    //$remember = $_POST[ 'remember' ];

    if ( empty( $username ) || empty( $password ) ) {
        $log_message = "用户名或密码不能为空";
    } else {


        if ( ( $username == 'a' ) && ( $password == 'a' ) ) {
            setcookie( "user_name", $username, time() + 365 * 24 * 3600, "/" );
            setcookie( "user_status", 1, time() + 365 * 24 * 3600, "/" );
            $log_message = "登录成功 ";
            header( "Location: /accounts/?login" );
        } else {
            $log_message = "用户名或密码错误 ";
        }


    }
}


$local_dir = __DIR__; 
$local_path = dirname($_SERVER['SCRIPT_NAME']);
$root_dir = $_SERVER[ 'DOCUMENT_ROOT' ];

$contentfile = $root_dir . "/connect/generic-connect.php";
if ( file_exists( "$contentfile" ) ) {
    include "$contentfile";
} else {
    echo 'ERR,code=FVXKFB';
}
