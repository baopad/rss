<?php
if ( ( $username == 'a' ) && ( $password == 'a' ) ) {
    setcookie( "user_name", $username, time() + 365 * 24 * 3600, "/" );
    setcookie( "user_status", 1, time() + 365 * 24 * 3600, "/" );
	$log_message = "登录成功 ";
    header( "Location: index.php" );
} else {
    $log_message = "用户名或密码错误 ";
}

?>