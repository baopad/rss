# index.php  //载入引导文件，模板格式


# index-localnav.php  //载入本地导航
修改index-localnav.php文件，修改导航样式

# index-localcontent.php  //载入本地正文
修改index-localcontent.php文件，修改正文内容



# index-localdatabase.php  //如无本地文件，从数据库载入
修改index-localdatabase.php文件，调整数据库接入