<div class="lc-menu">
    <ul class="lc-menu-case">
        <?php if ( !(( isset( $_COOKIE[ "user_status" ]) ? $_COOKIE[ "user_status" ] : 0 ) == 1 ) ) {?>
        <li class="lc-menu-item"><a href="/accounts/login/">登录</a> </li>
        <li class="lc-menu-item"><a href="/accounts/signup/">注册</a> </li>
        <?php } else { ?>
        <li class="lc-menu-item"><a href="/accounts/overview/">信息</a> </li>
        <li class="lc-menu-item"><a href="/accounts/edit/">设置</a> </li>
        <li class="lc-menu-item"><a href="/accounts/login/index.php?logout">注销</a> </li>
        <?php } ?>
        <li class="lc-menu-item"><a href="/accounts/faq/">常见问题</a> </li>
    </ul>
</div>
