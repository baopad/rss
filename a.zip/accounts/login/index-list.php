<div class="lc-list">
    <div class="lc-list-case">
        <h4 class="lc-list-title">
            <svg class="octicon" viewBox="0 0 16 16" height="16" width="16">
                <path fill-rule="evenodd" d="M0 1.75A.75.75 0 01.75 1h4.253c1.227 0 2.317.59 3 1.501A3.744 3.744 0 0111.006 1h4.245a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-4.507a2.25 2.25 0 00-1.591.659l-.622.621a.75.75 0 01-1.06 0l-.622-.621A2.25 2.25 0 005.258 13H.75a.75.75 0 01-.75-.75V1.75zm8.755 3a2.25 2.25 0 012.25-2.25H14.5v9h-3.757c-.71 0-1.4.201-1.992.572l.004-7.322zm-1.504 7.324l.004-5.073-.002-2.253A2.25 2.25 0 005.003 2.5H1.5v9h3.757a3.75 3.75 0 011.994.574z"></path>
            </svg>
            创建账户，包含以下服务</h4>
        <ul class="lc-list-sub">
            <li class="lc-list-item"><a href="#01">电子邮件</a> </li>
            <li class="lc-list-item"><a href="#02">网盘储层</a></li>
            <li class="lc-list-item"><a href="#03">数据库</a> </li>
            <li class="lc-list-item"><a href="#04">文件管理</a> </li>
           <li class="lc-list-item"><a href="#05">个人信息的保护</a> </li>
           <li class="lc-list-item"><a href="#06">个人信息的保护</a> </li>
          <li class="lc-list-item"><a href="#55">Overview</a> </li>
        </ul>
        
    </div>
</div>
