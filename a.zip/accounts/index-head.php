<div class="lc-nav">
    <div class="lc-nav-case">
        <h2 class="lc-nav-label"><a href="/accounts/">账号系统</a></h2>
        <div class="lc-nav-menuicon">
            <label class="lc-nav-menuicon-label" for="lc-menustates">
            <div class="lc-nav-menuicon-label-case">
                <div class="lc-nav-menuicon-label-left">
                    <div class="lc-nav-menuicon-label-left-crust"></div>
                </div>
                <div class="lc-nav-menuicon-label-right">
                    <div class="lc-nav-menuicon-label-right-crust"></div>
                </div>
            </div>
            </label>
        </div>
    </div>
</div>
