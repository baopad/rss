<?php
$local_dir = __DIR__;
$local_path = dirname( $_SERVER[ 'SCRIPT_NAME' ] );
$contentfile = $_SERVER[ 'DOCUMENT_ROOT' ] . "/connect/generic-connect.php";
if ( file_exists( "$contentfile" ) ) {
    include "$contentfile";
} else {
    echo 'ERR,code=FVXKFB.';
}