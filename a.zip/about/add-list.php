<div class="lm-list-case">
    <div class="lm-list-name-case">
        <div class="lm-list-case-title">
            <svg class="octicon" viewBox="0 0 16 16" height="16" width="16">
                <path fill-rule="evenodd" d="M0 1.75A.75.75 0 01.75 1h4.253c1.227 0 2.317.59 3 1.501A3.744 3.744 0 0111.006 1h4.245a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-4.507a2.25 2.25 0 00-1.591.659l-.622.621a.75.75 0 01-1.06 0l-.622-.621A2.25 2.25 0 005.258 13H.75a.75.75 0 01-.75-.75V1.75zm8.755 3a2.25 2.25 0 012.25-2.25H14.5v9h-3.757c-.71 0-1.4.201-1.992.572l.004-7.322zm-1.504 7.324l.004-5.073-.002-2.253A2.25 2.25 0 005.003 2.5H1.5v9h3.757a3.75 3.75 0 011.994.574z"></path>
            </svg>
            <span>&nbsp;</span><a href="<?php echo $directory_path ;?>"><?php echo '小工具' ;?></a> </div>
    </div>
    <div class="lm-list-case-case">
        <ul class="lm-list-case-subs">
            <?php if ( !(( isset( $_COOKIE[ "user_status" ]) ? $_COOKIE[ "user_status" ] : 0 ) == 1 ) ) {?>
            <li class="lm-list-case-item"><a href="/accounts">账号系统</a> </li>
            <li class="lm-list-case-item"><a href="/filemanager">文件管理</a> </li>
			<li class="lm-list-case-item"><a href="/tools/probe">PHP探针</a> </li>
<li class="lm-list-case-item"><a href="/tools/phpinfo">PHP信息</a> </li>
            <?php } else { ?>
            <li class="lm-list-case-item"><a href="/about?info">信息</a> </li>
            <li class="lm-list-case-item"><a href="/about?setup">设置</a> </li>
            <li class="lm-list-case-item"><a href="/about?logout">注销</a> </li>
            <?php } ?>
            <li class="lm-list-case-item"><a href="/about?faq">FAQ</a> </li>
        </ul>
    </div>
</div>
