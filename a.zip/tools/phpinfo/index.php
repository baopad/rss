<?php

                 phpinfo();

               ?>