<!--*************************开始*************************-->
<meta charset="utf-8">
<h2 align="center">Xray网络代理配置</h2>
<strong class=" ">前置条件</strong>
<p>1.一台VPS虚拟机。<br>
    2.你有一个域名，并指向VPS地址<br>
    3.域名A记录指向VPS</p>
<strong class="typography-subsection-headline">一、安装xray</strong>
<p>sudo -i<br>
    sudo apt update<br>
    bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install -u root<br>
    cat &gt; /usr/local/etc/xray/./config.json &lt;&lt;EOF<br>
    {<br>
    &quot;inbounds&quot;: [<br>
    {<br>
    &quot;port&quot;: 8443,<br>
    &quot;listen&quot;: &quot;127.0.0.1&quot;,<br>
    &quot;protocol&quot;: &quot;vless&quot;,<br>
    &quot;settings&quot;: {<br>
    &quot;clients&quot;: [<br>
    {<br>
    &quot;id&quot;: &quot;3a2cc75a-5fc1-4123-983b-7a1c86a10888&quot;,<br>
    &quot;level&quot;: 0<br>
    }<br>
    ],<br>
    &quot;decryption&quot;: &quot;none&quot;<br>
    },<br>
    &quot;streamSettings&quot;: {<br>
    &quot;network&quot;: &quot;ws&quot;,<br>
    &quot;security&quot;: &quot;none&quot;,<br>
    &quot;wsSettings&quot;: {<br>
    &quot;path&quot;: &quot;/ray&quot;<br>
    }<br>
    }<br>
    }<br>
    ],<br>
    &quot;outbounds&quot;: [<br>
    {<br>
    &quot;protocol&quot;: &quot;freedom&quot;,<br>
    &quot;settings&quot;: {}<br>
    }<br>
    ]<br>
    }<br>
    EOF<br>
</p>
<p><strong class="typography-subsection-headline">二、Certbot安装&配置</strong></p>
<p>apt install certbot python-certbot-apache<br>
    certbot certonly --apache -d aws.paotung.org<br>
    certbot renew --dry-run</p>
<p><strong class="typography-subsection-headline">三、Apache安装&配置</strong> </p>
<p>apt install apache2 php libapache2-mod-php<br>
    a2enmod proxy proxy_wstunnel proxy_http proxy_http2 ssl rewrite headers<br>
    systemctl restart apache2<br>
    mkdir -p /var/www/aws.paotung.org<br>
    chmod -R 777 /var/www/aws.paotung.org<br>
    cat &gt; /etc/apache2/sites-available/./aws.paotung.org.conf &lt;&lt;EOF<br>
    &lt;VirtualHost *:80&gt;<br>
    ServerName aws.paotung.org<br>
    DocumentRoot /var/www/aws.paotung.org<br>
    RewriteEngine On<br>
    RewriteCond %{HTTPS} off<br>
    RewriteRule (.*) https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]<br>
    &lt;/VirtualHost&gt;<br>
    &lt;VirtualHost *:443&gt;<br>
    ServerAdmin admin@localhost<br>
    ServerName aws.paotung.org<br>
    DocumentRoot /var/www/aws.paotung.org<br>
    SSLProxyEngine On<br>
    ProxyPass &quot;/ray&quot; &quot;ws://localhost:8443/ray&quot;<br>
    ProxyPassReverse &quot;/ray&quot; &quot;ws://localhost:8443/ray&quot;<br>
    SSLEngine On<br>
    SSLCertificateFile /etc/letsencrypt/live/aws.paotung.org/fullchain.pem<br>
    SSLCertificateKeyFile /etc/letsencrypt/live/aws.paotung.org/privkey.pem<br>
    Include /etc/letsencrypt/options-ssl-apache.conf<br>
    &lt;/VirtualHost&gt;<br>
    EOF<br>
    a2ensite aws.paotung.org.conf<br>
    apache2ctl configtest<br>
    systemctl reload apache2<br>
    systemctl enable apache2<br>
    systemctl status apache2<br>
    sh -c 'echo &quot;hello world!&quot; &gt; /var/www/aws.paotung.org/index.html'</p>
<p><strong class="typography-subsection-headline">四、BBR配置加速</strong></p>
<p>uname -v<br>
    echo &quot;net.core.default_qdisc=fq&quot; &gt;&gt; /etc/sysctl.conf<br>
    echo &quot;net.ipv4.tcp_congestion_control=bbr&quot; &gt;&gt; /etc/sysctl.conf<br>
    sysctl -p<br>
    sysctl net.ipv4.tcp_available_congestion_control<br>
lsmod | grep bbr</p>
<p><strong class="typography-subsection-headline">五、Crontab安装&amp;配置</strong></p>
<p>apt install cron<br>
    systemctl start cron<br>
    systemctl enable cron<br>
    crontab -e<br>
    0 0 1 * * /sbin/reboot</p>
<p><strong class="typography-subsection-headline">六、测试&amp;使用</strong></p>
<p>sh -c 'echo &quot;hello world&quot; &gt; /var/www/aws.paotung.org/index.html'<br>
    reboot<br>
</p>
<p><br>
</p>
