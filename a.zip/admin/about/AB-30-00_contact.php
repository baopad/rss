
<h2 align="center">联系我们</h2>
<strong class="">电子邮件</strong>
<div style="margin: 0 24px;">
    <p> blog@paotung.org</p>
</div>
<strong>在线反馈</strong>
<div style="margin: 0 24px;">
    <p>星号（<span  style="color: #e71d32;">*</span>）表示完成该事务所需的字段。</p>
    <form action="/csmail.php" method="post">
        <p>
            <input type="hidden" name="Subject" value="客户投诉">
        </p>
        <p class="ibm-padding-top-1">
            <label id="chenghu">称呼:<span style="color: #e71d32;">*</span></label>
            <input name="radiogrp2" type="radio" value="先生">
            <label for="xiansheng">先生</label>
            <input name="radiogrp2" type="radio" value="女士">
            <label for="nvshi">女士</label>
        </p>
        <p>
            <label for="NFNAME">姓名:<span style="color: #e71d32;">*</span></label>
            <br>
            <input value="" size="40" name="NFNAME" type="text" style="line-height: 2.0">
        </p>
        <p>
            <label for="email">电子邮箱:<span style="color: #e71d32;">*</span></label>
            <br>
            <input value="" size="40" name="email" type="text" style="line-height: 2.0">
            <br>
        </p>
        <p>
            <label for="YOUR_TEL">联系电话:</label>
            <br>
            <input value="" size="40" name="YOUR_TEL" type="text" style="line-height: 2.0">
            <br>
            <span>如果为固定电话号码，请注明区号。</span> </p>
        <p>
            <label for="Advice">意见:<span style="color: #e71d32;">*</span></label>
            <br>
            <textarea class="inquiry-input" id="Advice" rows="8" cols="42" name="Advice"></textarea>
            <br>
            <span>如果涉及博客内容，请注明博客页面。 </span> </p>
        <p> 
            <button type="submit" name="submit" value="提交"> 提交 </button>
            &nbsp;&nbsp;
            <button type="reset" name="cancel" value="取消"> 取消 </button>
            </span> </p>
    </form>
</div>
