
<main id="localmain">
    <input type="checkbox" id="lm-menustates">
    <div id="lm-content">
        <div class="lm-content-case"> </div>
    </div>
    
    <section class="8520" style="height: 600px; background-color: aliceblue">此处显示  class "8520" 的内容</section>
	<section class="8520" style="height: 600px; background-color: navy">此处显示  class "8520" 的内容</section>
</main>
