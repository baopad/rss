<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/styles/globalstrap.txt';
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/styles/globalnav.txt';
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/styles/globalfooter.txt';
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/main/styles/generalmain.txt';

?>	
</head>
<body style="direction:r tl;">
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/globalnav.html';
?>
<?php
include './localnav.html';
echo '测试页面<a href="./privacy"> privacy</a>'
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/globalfooter.html';
?>
</body>
</html>