<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/styles/globalstrap.txt';
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/styles/globalnav.txt';
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/styles/globalfooter.txt';
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/main/styles/generalmain.txt';

?>	
</head>
<body style="direction:rtl;">
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/globalnav.html';
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/legal/localnav.html';
include './content.html';
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/globalfooter.html';
?>
</body>
</html>