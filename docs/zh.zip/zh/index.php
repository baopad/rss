<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<?php include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/globalstrap.txt'; ?>
</head>
<body style="direction:r tl;">
	
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/globalstrap.txt';
?>

<?php
$f_info = implode( "", file( "https://folders.paotung.org/main" ) );
echo $f_info;
?>
	
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/globalfooter.txt';
?>
	
</body>
</html>