<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="PAOTUNG">
<meta name="description" content="paotung website">
<link rel="stylesheet" type="text/css" href="https://folders.paotung.org/styles/globalstrap.css">
<link rel="stylesheet" type="text/css" href="https://folders.paotung.org/styles/globalnav.css">
<link rel="stylesheet" type="text/css" href="https://folders.paotung.org/styles/legalmain.css">
<link rel="stylesheet" type="text/css" href="https://folders.paotung.org/styles/contactmain.css">
<link rel="stylesheet" type="text/css" href="/zh/footer/styles/globalfooter.css">
<link rel="shortcut icon" href="https://folders.paotung.org/favicon/favicon-pt.ico" type="image/x-icon">
<link rel="icon" href="https://folders.paotung.org/favicon/favicon-pt_96.png" sizes="96">
<title>PAOTUNG</title>
</head>
<body>

<?php   
  $f_info=implode("",file("https://folders.paotung.org/nav"));   
  echo   $f_info;   
  ?>
  
  <?php   
  $f_info=implode("",file("https://folders.paotung.org/main"));   
  echo   $f_info;   
  ?>
  
<?php   
  $f_info=implode("",file("/zh/footer/globalfooter/globalfooter.txt"));   
  echo   $f_info;   
  ?>
  
</body>
</html>