<?php   
  include $_SERVER['DOCUMENT_ROOT'] . '/zh/head/globalhead/globalstrap.txt';  
  ?>

<?php   
  $f_info=implode("",file("https://folders.paotung.org/nav"));   
  echo   $f_info;   
  ?>
  
  <?php   
  $f_info=implode("",file("https://folders.paotung.org/main"));   
  echo   $f_info;   
  ?>
  
<?php   
  include $_SERVER['DOCUMENT_ROOT'] . '/zh/footer/globalfooter/globalfooter.txt';  
  ?>
  
</body>
</html>