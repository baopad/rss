<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<?php
//头部样式
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/styles/globalhead.txt';
//正文样式
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/main/styles/localmain.txt';
?>
</head>

<body style="direction:rtl;">
<?php
//全局导航
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/globalnav.html';
//二级本地导航
include '../localnav.html';
//三级正文内容	
include './localcontent.html';
//页尾导航
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/globalfooter.html';
?>
</body>
</html>