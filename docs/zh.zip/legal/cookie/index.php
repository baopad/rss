<?php

echo '<body style="direction:rtl;">';
//导入头页面及全局样式
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/globalhead.php';

echo '<body style="direction:rtl;">';
/* 全局导航 */
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/globalnav.php';
?>


<?php

//二级本地导航
include '../localnav.html';
//三级正文内容	
include './localcontent.html';

?>

<?php
//导入页尾
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/globalfooter.php';
?>
