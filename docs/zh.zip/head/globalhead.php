<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="PAOTUNG">
<meta name="description" content="paotung website">
<?php // 全局页头样式 ?>
<link rel="stylesheet" type="text/css" href="<?php echo"$lang";?>/head/styles/globalstrap.css">
<link rel="stylesheet" type="text/css" href="<?php echo"$lang";?>/nav/styles/globalnav.css">
<?php // 本地页面样式 ?>
<link rel="stylesheet" type="text/css" href="<?php echo"$lang";?>/main/styles/localnav.css">
<link rel="stylesheet" type="text/css" href="<?php echo"$lang";?>/main/styles/localcontent.css">
<link rel="stylesheet" type="text/css" href="<?php echo"$lang";?>/main/styles/localoverview.css">
<?php // 全局页尾样式 ?>
<link rel="stylesheet" type="text/css" href="<?php echo"$lang";?>/footer/styles/globalfooter.css">
<link rel="shortcut icon" href="<?php echo"$lang";?>/head/favicon/favicon-pt.ico" type="image/x-icon">
<link rel="icon" href="<?php echo"$lang";?>/head/favicon/favicon-pt_96.png" sizes="96">
<title>PAOTUNG</title>
</head>
<body style="direction:r tl;">
