<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<?php
//头部样式
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/styles/globalhead.txt';
//正文样式
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/main/styles/localmain.txt';
?>
</head>

<body style="direction:r tl;">
<?php
//全局导航
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/globalnav.html';
//本地导航
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/main/localnav.html';
//正文内容	
echo '二级主页面 测试页面<a href="./legal"> legal</a>';
//页尾导航
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/globalfooter.html';
?>
</body>
</html>