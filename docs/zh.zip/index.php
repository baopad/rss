<?php
$lang = $_SERVER[ 'PHP_SELF' ];

function cut_str( $str, $sign, $number ) {
    $array = explode( $sign, $str );
    $length = count( $array );
    if ( $number < 0 ) {
        $new_array = array_reverse( $array );
        $abs_number = abs( $number );
        if ( $abs_number > $length ) {
            return 'error';
        } else {
            return $new_array[ $abs_number - 1 ];
        }
    } else {
        if ( $number >= $length ) {
            return 'error';
        } else {
            return $array[ $number ];
        }
    }
}
$lang = '/' . cut_str( $lang, '/', 1 );
echo "$lang"
?>

<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . "$lang/head/globalhead.php";
/* 全局导航 */
include $_SERVER[ 'DOCUMENT_ROOT' ] . "$lang/nav/globalnav.php";
?>

<?php
/* 本地导航 */
include $_SERVER[ 'DOCUMENT_ROOT' ] . "$lang/main/localnav.php";
/* 正文内容 */
echo '二级主页面默认main 测试页面<a href="./legal"> 二级legal页面</a>';
?>

<?php
//导入页尾
include $_SERVER[ 'DOCUMENT_ROOT' ] . "$lang/footer/globalfooter.php";
?>
