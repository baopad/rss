<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/head/styles/globalhead.txt';
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/main/styles/localmain.txt';
?>	
</head>
<body style="direction:r tl;">
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/nav/globalnav.html';
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/main/localmain.html';
?>
<?php
include $_SERVER[ 'DOCUMENT_ROOT' ] . '/zh/footer/globalfooter.html';
?>
</body>
</html>