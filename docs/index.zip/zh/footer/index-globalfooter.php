<?php
//$lang 在目录文件index.php中定义
include $_SERVER[ 'DOCUMENT_ROOT' ] . "$lang/footer/globalfooter.php";
?>