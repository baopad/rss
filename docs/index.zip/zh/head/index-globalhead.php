<?php
//$lang 在目录文件index.php中定义
// 载入页面头信息
include $_SERVER[ 'DOCUMENT_ROOT' ] . "$lang/head/globalhead.php";
// 载入全局导航条
include $_SERVER[ 'DOCUMENT_ROOT' ] . "$lang/nav/globalnav.php";
?>